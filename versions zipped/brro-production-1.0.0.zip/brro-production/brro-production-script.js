jQuery(function($) {
	// Tested functions for the website in production mode only - no developing here, use Code Snippets for testing.
});