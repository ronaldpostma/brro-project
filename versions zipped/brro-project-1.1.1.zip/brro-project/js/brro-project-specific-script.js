jQuery(function($) {
    // custom post functions
});